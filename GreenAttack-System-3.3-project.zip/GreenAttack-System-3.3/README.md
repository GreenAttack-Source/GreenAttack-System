# GreenAttack-System 3.3 — Quellcode

Eigenständiges Paper-Plugin. Die passende `GreenAttack-System-3.3.jar` liegt separat im Repository.

## Bauen

Voraussetzung: Java 25. Unter Windows im entpackten Projektordner ausführen:

```powershell
.\gradlew.bat build
```

Die Abhängigkeiten werden beim Bauen von den in `build.gradle` eingetragenen Maven-Repositories geladen.